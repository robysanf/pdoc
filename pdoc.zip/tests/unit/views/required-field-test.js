import {
  moduleFor,
  test
} from 'ember-qunit';

moduleFor('view:required-field', 'RequiredFieldView');

// Replace this with your real tests.
test('it exists', function() {
  var view = this.subject();
  ok(view);
});
