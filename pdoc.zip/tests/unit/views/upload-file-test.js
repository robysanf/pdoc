import {
  moduleFor,
  test
} from 'ember-qunit';

moduleFor('view:upload-file', 'UploadFileView');

// Replace this with your real tests.
test('it exists', function() {
  var view = this.subject();
  ok(view);
});
