import {
  showSelectionsHelper
} from 'p-doc/helpers/show-selections-helper';

module('ShowSelectionsHelperHelper');

// Replace this with your real tests.
test('it works', function() {
  var result = showSelectionsHelper(42);
  ok(result);
});
