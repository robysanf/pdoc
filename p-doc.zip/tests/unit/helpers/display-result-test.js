import {
  displayResult
} from 'p-doc/helpers/display-result';

module('DisplayResultHelper');

// Replace this with your real tests.
test('it works', function() {
  var result = displayResult(42);
  ok(result);
});
