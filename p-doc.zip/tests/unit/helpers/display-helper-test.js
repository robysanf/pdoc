import {
  displayHelper
} from 'p-doc/helpers/display-helper';

module('DisplayHelperHelper');

// Replace this with your real tests.
test('it works', function() {
  var result = displayHelper(42);
  ok(result);
});
