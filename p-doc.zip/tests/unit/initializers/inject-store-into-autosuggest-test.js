import Ember from 'ember';
import { initialize } from 'p-doc/initializers/inject-store-into-autosuggest';

var container, application;

module('InjectStoreIntoAutosuggestInitializer', {
  setup: function() {
    Ember.run(function() {
      container = new Ember.Container();
      application = Ember.Application.create();
      application.deferReadiness();
    });
  }
});

// Replace this with your real tests.
test('it works', function() {
  initialize(container, application);

  // you would normally confirm the results of the initializer here
  ok(true);
});

