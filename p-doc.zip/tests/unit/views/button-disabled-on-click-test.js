import {
  moduleFor,
  test
} from 'ember-qunit';

moduleFor('view:button-disabled-on-click', 'ButtonDisabledOnClickView');

// Replace this with your real tests.
test('it exists', function() {
  var view = this.subject();
  ok(view);
});
