import {
  moduleFor,
  test
} from 'ember-qunit';

moduleFor('view:tooltip', 'TooltipView');

// Replace this with your real tests.
test('it exists', function() {
  var view = this.subject();
  ok(view);
});
