import {
  moduleFor,
  test
} from 'ember-qunit';

moduleFor('view:modal-manager', 'ModalManagerView');

// Replace this with your real tests.
test('it exists', function() {
  var view = this.subject();
  ok(view);
});
